import ReactDOM from "react-dom/client";
import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css"
import "./App.css";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Authentification from "./screens/login.js";
import ItemListing from "./screens/itemListing.js";
import Item from "./screens/item.js";

export default function App() {

  const [itemRoutes, setItemRoutes] = useState([]);

  useEffect( () => {
    fetch("https://marche-puces.azurewebsites.net/items?limit=100")
    .then(async response => setItemRoutes(await response.json()))
  })
  return (
    <BrowserRouter>
      {itemRoutes.map(link => {<Link to={'/item/' + link.id}/>})}
      <Routes>
        <Route exact path="/" element={<ItemListing/>}/>
        <Route path="/auth" element={<Authentification/>}/>
        <Route path="item/:id" component={<Item/>}/>
      </Routes>
    </BrowserRouter>
  )
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
