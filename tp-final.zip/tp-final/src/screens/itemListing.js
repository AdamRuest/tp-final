import React, { useCallback, useRef } from "react";
import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from "react";

let searchQuery = "";
let categoryQuery = "";
let sortQuery = "";

// Je n'ai pas trouver pourquoi ni comment le régler, mais il faut rechercher 2 fois pour que les filtres s'appliquent et il faut rechercher une première fois pour que les données se chargent
// Les pages des object individuelle sont router et existe, mais il ne semble pas avoir de donnée qui se font return
// Je n'ai pas réussi à faire fonctionner la connexion, mais le code pour le favoris est là

export default function ItemListing() {
  
  let navigate = useNavigate();
  const [isLoggedIn, changeAuthStatus] = useState(false);
  const [viewFavorite, changeFavoriteState] = useState(false);
  const [itemsResult, setItems] = useState([]);
  const [favoriteItems, setFavorites] = useState([]);
  const [itemSection, setItemSection] = useState([]);

  useEffect( () => {
    async function fetchData(){
      try {
        let response = await fetch("https://marche-puces.azurewebsites.net/items?" + searchQuery + categoryQuery + sortQuery + "limit=1000", {mode: 'cors'})
        console.log(response);
        setItems(await response.json());
        let temp = viewFavorite ? async function() {
          let favResponse = await fetch("https://marche-puces.azurewebsites.net/tokenInfo", {mode: 'cors'});
          setFavorites(await favResponse.json());
        } : null
      } catch (err) {
        console.log(err);
      }
    }
    fetchData();

    const script = document.createElement('script');
    script.src = "https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js";
    script.integrity = "sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz";
    script.crossOrigin = "anonymous";
    document.body.appendChild(script);
  }, []);

  const fetchData = useCallback(async () => {
    try {
      let response = await fetch("https://marche-puces.azurewebsites.net/items?limit=100&" + searchQuery + categoryQuery + sortQuery, {mode: 'cors'})
      setItems(await response.json());
      let temp = viewFavorite ? async function() {
        let favResponse = await fetch("https://marche-puces.azurewebsites.net/tokenInfo", {mode: 'cors'});
        setFavorites(await favResponse.json());
      } : null
    } catch (err) {
      console.log(err);
    }
  })

  async function proccessSearch() { 
    setItemSection([]); 
    await fetchData();
    loadItems();
  }

  function loadItems() {
    if (viewFavorite === true ) {
      changeFavoriteState(false);
  
      itemsResult.forEach(article => {
        if (favoriteItems.favorites.contains(article.id))
        {
          setItemSection( prevItemSection => [...prevItemSection, article])
        }
      })
    } else {
      itemsResult.forEach(article => {
      setItemSection( prevItemSection => [...prevItemSection, article]);
    })}
    console.log(itemsResult);
    console.log(itemSection);
  }


  function navigateLogin() {
    navigate('/auth');
  }

  function navigateItem(id) {
    navigate('/item/' + id);
  }

  async function signoutUser() {
    fetch("https://marche-puces.azurewebsites.net", {
      method: 'post',
      mode: 'cors'
    })
    changeAuthStatus(false);
  }

  return (
    <div id="body">     
      <header id="header" class="d-flex justify-content-around align-middle bg-secondary">
        <div id="filters" class="d-flex mt-3 mb-3 w-25 justify-content-around">
          <div class="dropdown">
            <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Catégories </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
              <a class="dropdown-item" onClick={ () => {categoryQuery = "categorie=Accessoire+de+mode&" }}> Accessoire de mode </a>
              <a class="dropdown-item" onClick={ () => {categoryQuery = "categorie=Famille&" }}> Famille </a>
              <a class="dropdown-item" onClick={ () => {categoryQuery = "categorie=Électronique&" }}> Électronique </a>
              <a class="dropdown-item" onClick={ () => {categoryQuery = "categorie=Véhicule&" }}> Véhicule </a>
              <a class="dropdown-item" onClick={ () => {categoryQuery = "categorie=Maison+et+jardin&" }}> Maison et jardin </a>
              <a class="dropdown-item" onClick={ () => {categoryQuery = "categorie=Aubaine&" }}> Aubaine </a>
            </div>
          </div>
          <div class="dropdown">
            <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Trier </button>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton2">
              <li><a class="dropdown-item" onClick={ () => {sortQuery = "sort=price_asc&" }}> Prix(Ascendant) </a></li>
              <li><a class="dropdown-item" onClick={ () => {sortQuery = "sort=price_des&" }}> Prix(Descendant) </a></li>
              <li><a class="dropdown-item" onClick={ () => {sortQuery = "sort=name_asc&" }}> Nom(Ascendant) </a></li>
              <li><a class="dropdown-item" onClick={ () => {sortQuery = "sort=name_des&" }}> Nom(Descendant) </a></li>
            </ul>
          </div>
          <button id="resetFilterButton" class="btn btn-danger" onClick={ () => {
            sortQuery = "";
            categoryQuery = "";
          }}> Retirer les filtres </button>
        </div>
        <input id="searchbar" class="h-25 w-25 mt-4" type="search" placeholder="Rechercher" onInput={ e => { searchQuery = "q=" + e.target.value + "&"; console.log(e.target.value)} }></input>
        <button id="searchButton" class="btn btn-primary mt-3 h-25 w-25" onClick={ () => { proccessSearch(); searchQuery=""; console.log(searchQuery + categoryQuery + sortQuery) }}> Chercher </button>
        <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle mt-3" type="button" id="dropdownMenuButton3" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Compte </button>
          <div id="accountDropDown" class="dropdown-menu" aria-labelledby="dropdownMenuButton3">
                {
                isLoggedIn ? 
                ( <>
                    <a class="dropdown-item" onClick={ () => {
                        changeFavoriteState(!viewFavorite);
                        window.location.reload(true);
                    }}> Favoris </a> 
                    <a class="dropdown-item" onClick={ () => { signoutUser() } }> Se déconnecter </a>
                  </>) : 
                  <a class="dropdown-item" onClick={ () => { navigateLogin() }}> S'enregistrer </a>
                }
          </div>
        </div>
      </header>
      <section className="itemSection">
        <ul> 
          { 
          itemSection.map(item =>
          <li key={item.id} class="border d-inline-block w-25 mr-2 ml-2" onClick={ () => { navigateItem(item.id) }}>
            <img src={item.image[0]} class="mx-auto mt-4 h-25 d-flex"></img>
            <h4 class="d-flex justify-content-center"> {item.name} </h4>
            <div class="d-flex justify-content-around">
              <p> {item.publication_date} </p>
              <p> {item.price}$ </p>
            </div>
          </li> 
        )} 
        </ul>
      </section>
    </div>
  )
}
