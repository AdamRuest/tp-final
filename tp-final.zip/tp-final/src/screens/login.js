import React, { useState } from "react"
import { useNavigate } from "react-router-dom";

let name = "";
let email = "";
let passwd = "";
let error = null;

export default function Authentification() {

  const navigate = useNavigate();
  let [logMode, setLogMode] = useState("signin");

  async function signinUser() {
    console.log("test");
    fetch("https://marche-puces.azurewebsites.net/signin", {
      method: 'post',
      mode: 'cors',
      body: JSON.stringify({"name": name, "email": email, "password": passwd})
    })
    .then(response => console.log(response))
    .catch(err => 
    {
      error = err;
      alert("Email invalide!");
      console.log(err);
    })
    if (error === null)
    {
      fetch("https://marche-puces.azurewebsites.net/login", {
        method: 'post',
        mode: 'cors',
        body: JSON.stringify({"email": email, "password": passwd})
      })
      .then(response => response.json())
      .then(navigate('/'))
    }
  }

  async function loginUser() {
    console.log("test");
    fetch("https://marche-puces.azurewebsites.net/login", {
      method: 'post',
      mode: 'cors',
      body: JSON.stringify({"email": email, "password": passwd})
    })
    .then(response => response.json())
    .then(response => console.log(response))
    .catch(err => 
    {
      error = err;
      alert("Identifiants invalide!");
      console.log(err)
    })
    if (error === null)
    {
      navigate('/');
    }
  }

  const changeLogMode = () => {
    setLogMode(logMode === "signin" ? "signup" : "signin")
  }

  if (logMode === "signin")
  {
    return (
    <div className="login-form-container">
      <form className="login-form">
        <div className="login-form-content">
          <h3 className="login-form-title">Se Connecter</h3>
          <div className="text-center">
              Pas enregistrer?{" "}
              <span className="link-primary" onClick={changeLogMode}> S'enregistrer </span>
          </div>
          <div className="form-group mt-3">
            <label>Addresse Mail</label>
            <input id="email" type="email" className="form-control mt-1" placeholder="E-Mail" onInput={ e => { email = e.target.value}}/>
          </div>
          <div className="form-group mt-3">
            <label>Mot de Passe</label>
            <input id="passwd" type="password" className="form-control mt-1" placeholder="Mot de passe"onInput={ e => { passwd = e.target.value}}/>
          </div>
          <div className="d-grid gap-2 mt-3">
            <button id="signin" type="submit" className="btn btn-primary" onSubmit={ async (e) => { loginUser() }}> Se connecter </button>
          </div>
        </div>
      </form>
    </div>
    )
  }

  return (
    <div className="login-form-container">
      <form className="login-form">
        <div className="login-form-content">
          <h3 className="login-form-title">S'enregistrer</h3>
          <div className="text-center">
            Déjà enregistrer?{" "}
            <span className="link-primary" onClick={changeLogMode}>Se connecter</span>
          </div>
          <div className="form-group mt-3">
            <label>Nom complet</label>
            <input id="name" type="text" className="form-control mt-1" placeholder="Nom" onInput={ e => { name = e.target.value}}/>
          </div>
          <div className="form-group mt-3">
            <label>Addresse Mail</label>
            <input id="email" type="email" className="form-control mt-1" placeholder="E-Mail" onInput={ e => { email = e.target.value}}/>
          </div>
          <div className="form-group mt-3">
            <label>Mot de Passe</label>
            <input id="passwd" type="password" className="form-control mt-1" placeholder="Mot de passe" onInput={ e => { email = e.target.value}}/>
          </div>
          <div className="d-grid gap-2 mt-3">
            <button id="signup" type="submit" className="btn btn-primary" onSubmit={ (e) => { signinUser() }}> S'enregistrer </button>
          </div>
        </div>
      </form>
    </div>
  )
}