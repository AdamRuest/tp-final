import React, { useEffect, useState} from "react";
import { useParams, withRouter } from "react-router";

export default function Item() {

    const [data, setData] = useState();
    const params = useParams();

    useEffect( () => { 
        fetch("https://marche-puces.azurewebsites.net/items/" + params.id)
        .then( response => console.log(response))
        .then( async response => setData(response.json()));
    })
    
    return (
        <div class="mainBody">
            <header class="w-100 bg-secondary">
                <button id="backButton" class="btn btn-primary"> &lt </button>
            </header>
            <h1> {data.name} </h1>
            <img src={(data.images[0]).toString()}/>
            <p> {data.description} </p>
            <h6> {data.price} </h6>
            <h6> {data.publication_date} </h6>
            <button id="addFavorite" onClick={ (e) => {
                if (e.target.inneHTML === "Ajouter aux favoris")
                {
                    fetch("https://marche-puces.azurewebsites.net/favorite", {
                        method: 'post',
                        body: JSON.stringify({"id": data.id})
                    })
                    e.target.innerHTML = "Retirer des favoris";
                }
                else {
                    fetch("https://marche-puces.azurewebsites.net/favorite/" + data.id, {
                        method: 'delete'
                    })
                    e.target.innerHTML = "Ajouter aux favoris";
                }
            }}> {
                fetch("https://marche-puces.azurewebsites.net/tokenInfo")
                .then(async response => response.json())
                .then( response => {
                    if (response.favorites.contains(data.id)) {
                        return "Retirer des favoris"
                    }
                    else {
                        return "Ajouter aux favoris"
                    }
                })
            } </button>
        </div>
        );
}